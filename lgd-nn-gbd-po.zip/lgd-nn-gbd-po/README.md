# LGD, NN, GBD & PO

A Pen created on CodePen.io. Original URL: [https://codepen.io/benjaminmajcen/pen/VwBLVyR](https://codepen.io/benjaminmajcen/pen/VwBLVyR).

When a user hovers over a custom marker, show a popup containing more information.

See the example: [https://docs.mapbox.com//mapbox-gl-js/example/popup-on-hover/](https://docs.mapbox.com//mapbox-gl-js/example/popup-on-hover/)